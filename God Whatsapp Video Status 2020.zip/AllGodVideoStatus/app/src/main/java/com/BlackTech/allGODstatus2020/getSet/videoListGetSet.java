package com.BlackTech.allGODstatus2020.getSet;

public class videoListGetSet {
    private String Id;
    private String videoDownload;
    private String videoFileName;
    private String videoImage;
    private String videoView;
    private String video_cat_id;
    private String video_category;
    private String video_subCat_id;
    private String video_subcategory;
    private String video_title;

    public String getId() {
        return this.Id;
    }

    public void setId(String str) {
        this.Id = str;
    }

    public String getVideo_category() {
        return this.video_category;
    }

    public void setVideo_category(String str) {
        this.video_category = str;
    }

    public String getVideo_subcategory() {
        return this.video_subcategory;
    }

    public void setVideo_subcategory(String str) {
        this.video_subcategory = str;
    }

    public String getVideo_title() {
        return this.video_title;
    }

    public void setVideo_title(String str) {
        this.video_title = str;
    }

    public String getVideoFileName() {
        return this.videoFileName;
    }

    public void setVideoFileName(String str) {
        this.videoFileName = str;
    }

    public String getVideoImage() {
        return this.videoImage;
    }

    public void setVideoImage(String str) {
        this.videoImage = str;
    }

    public String getVideoView() {
        return this.videoView;
    }

    public void setVideoView(String str) {
        this.videoView = str;
    }

    public String getVideoDownload() {
        return this.videoDownload;
    }

    public void setVideoDownload(String str) {
        this.videoDownload = str;
    }

    public String getVideo_cat_id() {
        return this.video_cat_id;
    }

    public void setVideo_cat_id(String str) {
        this.video_cat_id = str;
    }

    public String getVideo_subCat_id() {
        return this.video_subCat_id;
    }

    public void setVideo_subCat_id(String str) {
        this.video_subCat_id = str;
    }
}
