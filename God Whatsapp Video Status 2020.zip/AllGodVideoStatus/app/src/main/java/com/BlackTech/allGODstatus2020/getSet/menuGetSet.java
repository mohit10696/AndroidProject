package com.BlackTech.allGODstatus2020.getSet;

public class menuGetSet {
    private String cat_id;
    private String menu_category;

    public String getMenu_category() {
        return this.menu_category;
    }

    public void setMenu_category(String str) {
        this.menu_category = str;
    }

    public String getCat_id() {
        return this.cat_id;
    }

    public void setCat_id(String str) {
        this.cat_id = str;
    }
}
