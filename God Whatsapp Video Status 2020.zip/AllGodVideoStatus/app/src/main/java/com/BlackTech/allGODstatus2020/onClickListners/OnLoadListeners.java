package com.BlackTech.allGODstatus2020.onClickListners;

public interface OnLoadListeners {
    void onLoadMore();
}
