package com.BlackTech.allGODstatus2020.onClickListners;

import android.view.View;

public interface onDeleteClick {
    void onItemClick(View view, int i);
}
