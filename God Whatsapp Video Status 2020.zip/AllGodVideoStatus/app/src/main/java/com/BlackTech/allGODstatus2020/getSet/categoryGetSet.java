package com.BlackTech.allGODstatus2020.getSet;

public class categoryGetSet {
    private String imageName;
    private String subCategoryId;
    private String subCategoryName;

    public String getSubCategoryId() {
        return this.subCategoryId;
    }

    public void setSubCategoryId(String str) {
        this.subCategoryId = str;
    }

    public String getImageName() {
        return this.imageName;
    }

    public void setImageName(String str) {
        this.imageName = str;
    }

    public String getSubCategoryName() {
        return this.subCategoryName;
    }

    public void setSubCategoryName(String str) {
        this.subCategoryName = str;
    }
}
