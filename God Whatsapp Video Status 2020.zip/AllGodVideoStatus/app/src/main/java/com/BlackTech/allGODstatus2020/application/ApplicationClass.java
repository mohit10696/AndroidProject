package com.BlackTech.allGODstatus2020.application;

import android.app.Application;

public class ApplicationClass extends Application {
    public void onCreate() {
        super.onCreate();
    }
}
