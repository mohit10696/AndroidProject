package com.BlackTech.allGODstatus2020.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Categorys {
    @Expose
    @SerializedName("Img_Category")
    public String Img_Category;
    @Expose
    @SerializedName("Category")
    public String Category;
    @Expose
    @SerializedName("Id")
    public String Id;
}

